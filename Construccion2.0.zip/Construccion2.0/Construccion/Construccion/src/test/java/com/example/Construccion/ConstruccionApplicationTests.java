package com.example.Construccion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConstruccionApplicationTests {

	@Test
	void contextLoads() {
	}

}
